<template>
  <div>
    <!-- <a-menu-item key="4">
        <template #icon>
          <PieChartOutlined />
        </template>
        <router-link to="/antd">Antd</router-link>
    </a-menu-item>
    <a-sub-menu key="sub1">
      <template #icon>
        <MailOutlined />
      </template>
      <template #title>测试模块</template>
      <a-menu-item key="5">
        <router-link to="/gome/home">Home</router-link>
      </a-menu-item>
      <a-menu-item key="6">
        <router-link to="/gome/test">Test</router-link>
      </a-menu-item>
      <a-menu-item key="7">
        <router-link to="/gome/about">About</router-link>
      </a-menu-item>
      <a-menu-item key="8">
        <router-link to="/gome/antd">Antd</router-link>
      </a-menu-item>
    </a-sub-menu>
    <a-sub-menu key="sub2">
      <template #icon>
        <AppstoreOutlined />
      </template>
      <template #title>Navigation Two</template>
      <a-menu-item key="9">Option 9</a-menu-item>
      <a-menu-item key="10">Option 10</a-menu-item>
      <a-sub-menu key="sub3"
                  title="Submenu">
        <a-menu-item key="11">Option 11</a-menu-item>
        <a-menu-item key="12">Option 12</a-menu-item>
      </a-sub-menu>
    </a-sub-menu> -->
  </div>
</template>
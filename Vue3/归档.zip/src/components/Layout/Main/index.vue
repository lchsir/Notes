<template>
  <div class="main">
    <router-view />
  </div>
</template>

<style lang="scss" scoped>
.main {
  flex: 1;
  background: #f0f2f5;
  padding: 10px 30px;
  overflow: auto;
}
</style>
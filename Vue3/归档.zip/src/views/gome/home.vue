<template>
  <div class="home">
    <img alt="Vue logo" src="../../assets/logo.png">
    <p>欢迎来到vue3的世界</p>
  </div>
</template>

<script>
export default {
  name: 'Home',
}
</script>
